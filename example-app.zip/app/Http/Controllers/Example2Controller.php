<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\ExampleController;
class Example2Controller extends Controller
{
   function about()
   {
   	 return "Example2";
   }
}
