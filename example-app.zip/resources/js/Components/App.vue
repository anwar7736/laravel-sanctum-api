<template>
  <div>
     <p>{{name}}</p>
  </div>
</template>

<script>
export default {
    data(){
        return {
            name : "Anwar",
        }
    }
}
</script>

<style scoped>
    p{
        color:red;
    }
</style>
